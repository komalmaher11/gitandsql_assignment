﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBookingWebApi.Models
{
    public class FBS_Flight_Master
    {
        [Key]
        public int FBS_Flight_Id { get; set; }
        public string FBS_Flight_Origin { get; set; }
        public string FBS_Flight_Destination { get; set; }
        public DateTime FBS_Flight_Date { get; set; }
        public TimeSpan FBS_Flight_Time { get; set; }
        public int FBS_Flight_Fare { get; set; }



    }
}
