﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBookingWebApi.Models
{
    public class FBS_Booking_Transaction
    {
		[Key]
		public int FBS_Booking_Id { get; set; }
		public DateTime FBS_Booking_Date { get; set; }
		//[Display(Name = "FBS_Flight_Master")]
		public int FBS_Flight_Id { get; set; }
		public int FBS_Flight_Fare { get; set; }
		public string Cust_Fisrt_Name { get; set; }
		public string Cust_Last_Name { get; set; }
		public string Cust_EmailId { get; set; }
		public int Cust_Contact_No { get; set; }
		public string FBS_Booking_Status { get; set; }
	}
}
