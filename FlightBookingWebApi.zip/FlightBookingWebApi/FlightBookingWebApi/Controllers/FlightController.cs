﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightBookingWebApi.Data;
using FlightBookingWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightBookingWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightController : ControllerBase
    {
        private readonly UserDbContext context;
        public FlightController(UserDbContext _context)
        {
            context = _context;
        }
        [HttpPost("Add_Flight")]
        public IActionResult Add_Flight([FromBody] FBS_Flight_Master obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                context.fBS_Flight_Masters.Add(obj);
                context.SaveChanges();
                return Ok(new
                {
                    Message = "Flight info add"
                });
            }
        }
        [HttpPost("Get_Flight")]
        public IActionResult Get_Flight([FromBody] FBS_Flight_Master obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                var user = context.fBS_Flight_Masters.Where(a =>
                a.FBS_Flight_Origin == obj.FBS_Flight_Origin
                && a.FBS_Flight_Destination == obj.FBS_Flight_Destination &&
                a.FBS_Flight_Date == obj.FBS_Flight_Date);
                return Ok(user);

            }
        }
        [HttpGet("GetServiceLocation")]
        public IActionResult GetServiceLocation()
        {
            var userDetails = context.FBS_ServiceLocations.AsQueryable();
            return Ok(userDetails);
        }
        [HttpPost("Add_Passanger")]
        public IActionResult Add_Passanger([FromBody] FBS_Booking_Transaction obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                context.FBS_Booking_Transactions.Add(obj);
                context.SaveChanges();
                return Ok(new
                {
                    Message = "Passanger info add successfully!!!"
                });
            }
        }

        [Route("GetAllFlight")]
        [HttpGet]
        public object GetAllFlight()
        {
            var userDetails = context.fBS_Flight_Masters.AsQueryable();
            return Ok(userDetails);
        }
       
    }
}
