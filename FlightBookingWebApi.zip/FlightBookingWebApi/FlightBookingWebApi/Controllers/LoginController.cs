﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightBookingWebApi.Data;
using FlightBookingWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightBookingWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly UserDbContext context;
        public LoginController(UserDbContext _context)
        {
            context = _context;

        }
        [HttpGet("Users")]
        public IActionResult GetUsers()
        {
            var userDetails = context.Users.AsQueryable();
            return Ok(userDetails);
        }
        [HttpPost("signup")]
        public IActionResult SignUp([FromBody] FBS_User obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                context.Users.Add(obj);
                context.SaveChanges();
                return Ok(new
                {
                    Message = "User add successfully"
                });
            }

        }
        [HttpPost("Login")]
        public IActionResult Login([FromBody] FBS_User obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                var user = context.Users.Where(a =>
                a.Username == obj.Username
                && a.Password == obj.Password).FirstOrDefault();
                if (user != null)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = " Logged in Successfully"
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "User Not Found"
                    });
                }
            }
        }
    }
}
