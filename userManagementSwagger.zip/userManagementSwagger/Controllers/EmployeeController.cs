﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using userManagementSwagger.Data;
using userManagementSwagger.Models;

namespace userManagementSwagger.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmpDbcontext _db;
        public EmployeeController(EmpDbcontext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            IEnumerable<EmployeeList> employeeLists = _db.employeeLists;
            return View(employeeLists);
        }
    }
}
