﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using userManagementSwagger.Models;

namespace userManagementSwagger.Data
{
    public class EmpDbcontext: DbContext
    {
        public EmpDbcontext(DbContextOptions<EmpDbcontext> options) : base(options)
        {

        }
        public DbSet<EmployeeList> employeeLists { get; set; }
    }
}
