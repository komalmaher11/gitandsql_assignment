use sqlJoins;

CREATE TABLE [dbo]. [Employee](
[Empid] [Int] IDENTITY (1, 1) NOT NULL Primary key,
[EmpNumber] [nvarchar](50) NOT NULL,
[EmpFirstName] [nvarchar](150) NOT NULL,
[EmpLastName] [nvarchar](150) NULL,
[EmpEmail] [nvarchar](150) NULL,
[Managerid] [int] NULL,
[Departmentid] [INT]
)
CREATE TABLE [dbo].[Department](
[Departmenttid] [int] IDENTITY (1, 1) NOT NULL primary key,
[DepartmentName] [nvarchar](255) NOT NULL
)
x

insert into Employee
(EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A001','manav','rathi','manav@abc.com',2,2)
insert into Employee
(EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A002','adity','Kulkarni','aditya@abc.com',1,1)
insert into Employee (EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A003','rahul','Sharma','rahul@abc.com',1,2)
insert into Employee (EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)
values('A004','Vivek','rajput','vivek@abc.com',1,NULL)

insert into Department(DepartmentName)
values('Accounts')
insert into Department(DepartmentName)
values('Admin')
insert into Department(DepartmentName)
values('HR')
insert into Department(DepartmentName)
values('Technology')


select Empid,EmpFirstName,EmpLastName,DepartmentName 
from Employee e
inner join Department d
on e.Empid=d.Departmenttid ;

select e1.Empid, 
       e1.EmpFirstName+' '+e1.EmpLastName as EmployeeName, 
    e2.EmpFirstName+' '+e2.EmpLastName as ManagerName 
  from Employee e1 
     INNER JOIN Employee e2 
    on e1.Managerid=e2.Empid

/*
Query for the Left Outer Join
*/
select e.Empid, 
       e.EmpFirstName, 
   e.EmpLastName, 
    d.DepartmentName
  FROM Employee e 
     LEFT OUTER JOIN Department d 
     ON e.Departmentid=d.Departmenttid;

/*
Query for the Right Outer Join
*/

select d.DepartmentName, 
       e.Empid, e.EmpFirstName, 
    e.EmpLastName 
  FROM Employee e 
    RIGHT OUTER JOIN Department d
   ON e.Departmentid=d.Departmenttid

   /*Query for the Full Outer Join */
select e.Empid, 
       e.EmpFirstName, 
    e.EmpLastName, 
    d.DepartmentName 
  from Employee e
     full OUTER JOIN Department d
    on e.Departmentid=d.Departmenttid

	/*
	Query for the Cross Join
	*/
select  e.Empid,
       e.EmpFirstName,
       e.EmpLastName,
     d.DepartmentName 
 from Employee e 
 CROSS JOIN Department d
   