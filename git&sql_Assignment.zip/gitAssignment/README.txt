1.Git Assignments html,css and js on brances
2.Html Assignments
3.make changes on README.txt file 
4.create new branch
5.make changes in README.me files
6.css assignments